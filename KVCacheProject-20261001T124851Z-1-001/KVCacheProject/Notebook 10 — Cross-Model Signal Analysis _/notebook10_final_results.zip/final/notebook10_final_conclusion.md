
# Notebook 10 — Final Exploratory Conclusion

## Research question

Notebook 10 asked whether the online signals studied on
Qwen2.5-1.5B become more informative about page-level INT4
sensitivity when the experiment is repeated on Qwen2.5-3B.

This notebook is exploratory. Notebook 09 remains the frozen
confirmatory cross-model validation.

## Matched experimental setup

The 1.5B and 3B analyses use:

- the same 16-token logical pages;
- candidate Pages 6-120;
- a 32-token / two-page observation delay;
- the same affected-token normalized lifetime Delta-NLL target;
- matched attention, confidence, position, delayed-attention, and
  quantization-distortion features.

This removes the timing mismatch that affected the original
Notebook 06 analysis.

## Individual signals

Simple online signals do not generally become stronger at 3B.

The strongest individual matched 1.5B Reference correlation has
absolute Spearman rho approximately 0.406, while the strongest
individual 3B Reference correlation is approximately 0.239.

Eight 1.5B signals survive within-dataset FDR correction, whereas no
individual signal survives FDR correction on the 3B Reference or the
predeclared 3B Unseen_3 segment.

Delayed attention is the most interesting scale-dependent exception.

For `DelayedAttn_Mean_Mean`:

- 1.5B Reference: rho = -0.024
- 3B Reference: rho = +0.137
- 3B Unseen_3: rho = +0.129

This suggests modest transferable information in short-term future
usage, but the effect remains weak.

`V_NRMSE_Max` does not transfer as a reliable intrinsic sensitivity
signal:

- 1.5B Reference: rho = +0.301
- 3B Reference: rho = -0.004
- 3B Unseen_3: rho = -0.126

## Fixed 17-feature combined predictor

A single predeclared GradientBoostingRegressor was evaluated with no
feature selection or hyperparameter search.

On the 3B Reference sequence, pooled blocked out-of-fold prediction
reaches

rho = +0.385

for normalized lifetime risk.

However, this pooled result is not uniformly robust across page
regions. The mean within-fold rho is only

rho = +0.126,

with a range from -0.033 to +0.457.

After fitting on all Reference pages and transferring the model
unchanged to Unseen_3, normalized-risk correlation falls to

rho = +0.130
(p = 0.168).

The combined predictor therefore does not provide a strong transfer
advantage over the simple delayed-attention anchor.

## Safe-page identification

The practical mixed-precision problem requires finding pages that are
safe to demote to INT4.

On the frozen Unseen_3 transfer:

- top-10 risky-page overlap = 4/10;
- top-10 safe-page overlap = 2/10;
- top-20 risky-page overlap = 8/20;
- top-20 safe-page overlap = 4/20.

The predictor is therefore more useful for identifying risky pages
than for reliably identifying the safest pages.

## Final cross-notebook interpretation

Notebook 09 showed that Qwen2.5-3B is substantially more tolerant to
selective INT4 than Qwen2.5-1.5B.

Notebook 10 shows that this improvement should not be explained by
page sensitivity becoming easier to predict.

Instead, the evidence supports two distinct conclusions:

1. model scale materially affects robustness to aggressive KV-cache
   quantization;
2. reliable online safe-page prediction remains difficult.

The larger model reduces the cost of selection mistakes, but the
tested online signals do not eliminate those mistakes.

## Final practical recommendation

The strongest practical policy remains uniform INT8 KV-cache
quantization.

Across Qwen2.5-1.5B and Qwen2.5-3B it approximately halves analytical
KV-cache memory while producing very small quality degradation.

Selective per-vector INT4 remains scientifically promising because
oracle-selected subsets can perform extremely well, especially at
3B, but the present attention / confidence / recency / distortion
signals do not support a sufficiently reliable transferable demotion
controller.

## Implementation scope

All INT8/INT4 memory numbers in the project are analytical packed-cache
estimates.

The quality prototype quantizes and dequantizes values into the
standard FP16 DynamicCache rather than implementing custom packed
low-bit attention kernels.

No physical GPU-cache allocation, bandwidth reduction, generation
throughput, or runtime speedup claim is made.

Notebook 10 is the FINAL experimental notebook.
No Notebook 11 is planned.
