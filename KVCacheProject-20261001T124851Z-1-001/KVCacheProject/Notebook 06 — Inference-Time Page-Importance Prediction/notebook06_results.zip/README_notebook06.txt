Notebook 06 — Inference-Time Page-Importance Prediction
========================================================

Model
-----
Qwen/Qwen2.5-1.5B

Dataset
-------
WikiText-2 test sequence

Cache configuration
-------------------
Cache tokens: 2048
Page size: 16
Logical pages: 128
Candidate pages: 6-120

Oracle
------
Target:
Delta NLL = NLL_INT4 - NLL_INT8

Fixed future horizon:
128 tokens


INDIVIDUAL SIGNALS
==================

Immediate attention
-------------------
Best feature:
Attn_Self_LayerMax

Spearman rho:
0.153271


Confidence
----------
Best feature:
Conf_Entropy_Last

Spearman rho:
0.102225


Page position
-------------
Spearman rho:
-0.140582


Delayed attention
-----------------
Best feature:
DelayedAttn_Mean_Mean

Observation delay:
2 pages
(32 tokens)

Spearman rho:
0.125037


HYBRID REGRESSION
=================

Best feature set:
Delayed_2pages

Best model:
GradientBoosting

Blocked OOF Spearman rho:
0.162369


DIRECT CLASSIFICATION
=====================

High-sensitivity definition:
Delta NLL >= 0.3

Best high classifier:
Delayed_2pages / GradientBoosting

Overall OOF ROC-AUC:
0.744729

Overall OOF Average Precision:
0.479790


Low-sensitivity definition:
Delta NLL <= 0.15

Best low classifier:
Immediate / LogisticRegression

Overall OOF ROC-AUC:
0.541667

Overall OOF Average Precision:
0.423519


MAIN CONCLUSION
===============

The strongest predictive result in Notebook 06 is direct
classification of high-sensitivity pages.

High-sensitivity detection is moderately successful and is
reasonably stable across contiguous sequence regions.

Reliable identification of low-sensitivity pages remains
unsolved. The current low classifier is too weak and unstable
to serve as a trusted INT4 demotion rule.

Therefore the current conservative architecture is:

    high-confidence sensitive page -> FP16 candidate
    uncertain / normal page        -> INT8
    low page                        -> INT4 only when stronger
                                       evidence is available

INT8 remains the safe default.


IMPORTANT CAVEAT
================

The strongest high classifier observes attention for two
additional pages (32 tokens).

Notebook 05's sensitivity oracle assumes that the target page
is demoted immediately after completion.

Therefore a delay-aligned sensitivity oracle should be built
before this delayed predictor is treated as a final adaptive
policy.


NEXT STAGE
==========

1. Build a delay-aligned sensitivity oracle.
2. Re-evaluate delayed high-sensitivity prediction.
3. Define conservative FP16 / INT8 / INT4 decision thresholds.
4. Run actual cache-aware adaptive-policy PPL evaluation.
5. Measure memory-quality tradeoffs.
6. Compare against uniform INT8, oracle, recency, and random.