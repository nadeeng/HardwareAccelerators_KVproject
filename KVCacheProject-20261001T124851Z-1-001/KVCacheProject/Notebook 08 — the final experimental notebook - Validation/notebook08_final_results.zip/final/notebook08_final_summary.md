
# Notebook 08 — Final Validation Summary

## Final practical recommendation

**Uniform INT8**

- FP16 analytical KV memory: 56.000 MiB
- Uniform INT8 analytical KV memory: 28.027 MiB
- Memory saving vs FP16: 49.951%
- Mean INT8 PPL increase vs FP16 across five unseen segments:
  0.345%
- Worst INT8 PPL increase vs FP16 across five unseen segments:
  0.897%

## Frozen selective INT4 transfer

### L=2

- Memory: 27.822 MiB
- Additional saving vs uniform INT8:
  0.733%
- Mean unseen PPL increase:
  2.557%
- Worst unseen PPL increase:
  4.171%

### L=4

- Memory: 27.616 MiB
- Additional saving vs uniform INT8:
  1.466%
- Mean unseen PPL increase:
  3.756%
- Worst unseen PPL increase:
  5.490%

The frozen selective-INT4 predictor therefore does not provide a
robust practical improvement over uniform INT8.

## Oracle audit

On Unseen_3, oracle-informed single-page lifetime ranking followed
by joint evaluation gives:

- L=2: 0.040% PPL increase
- L=4: 0.651% PPL increase

The frozen policy on the same segment gives:

- L=2: 3.630% PPL increase
- L=4: 3.761% PPL increase

Therefore, substantially safer INT4 subsets exist, but the tested
inference-time predictor does not identify them reliably.

## Final conclusion

The project demonstrates that KV-cache page sensitivity is highly
heterogeneous and that oracle-informed page selection can make
low-bit quantization substantially more viable than naive assignment.

However, the tested attention, confidence, recency, and quantization-error
signals do not provide a sufficiently transferable predictor for
aggressive page-level INT4 assignment.

The strongest deployable conclusion from the current prototype is
therefore uniform INT8. It provides approximately half the analytical
FP16 KV-cache memory while remaining close to FP16 quality across the
five unseen validation segments.

Selective INT4 remains promising as future work, but requires a stronger
quantizer, a better transferable page-sensitivity estimator, or both.

Memory values are analytical packed-cache estimates. The prototype
dequantizes values into the standard FP16 DynamicCache and therefore
does not demonstrate physical low-bit GPU allocation or runtime speedup.
