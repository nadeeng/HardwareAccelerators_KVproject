
# Notebook 09 — Final Cross-Model Conclusion

## Purpose

Notebook 09 tested whether the conclusions obtained with
Qwen2.5-1.5B were specific to the relatively small development model.

The validation used Qwen2.5-3B while keeping the experimental protocol
fixed: WikiText-2, 2048-token cache, 16-token pages, a 32-token decision
delay, candidate Pages 6-120, per-vector INT4, L=2/L=4 budgets, the same
five unseen token windows, and the same StandardScaler + Ridge(alpha=1)
risk-prediction methodology.

No post-hoc feature engineering or policy tuning was performed.

## Uniform INT8

Uniform INT8 is the strongest result across both model sizes.

### Qwen2.5-1.5B

- FP16 analytical KV memory: 56.000 MiB
- INT8 analytical KV memory: 28.027 MiB
- analytical memory reduction: 49.951%
- mean unseen PPL change vs FP16: +0.345%
- worst unseen PPL change: +0.897%

### Qwen2.5-3B

- FP16 analytical KV memory: 72.000 MiB
- INT8 analytical KV memory: 36.035 MiB
- analytical memory reduction: 49.951%
- mean unseen PPL change vs FP16: +0.076%
- worst unseen PPL change: +0.238%

Therefore the approximately 50% analytical KV-memory reduction from
uniform INT8 transfers cleanly from 1.5B to 3B with very small
perplexity degradation.

## Selective INT4 and model scale

The main new result is that selective INT4 is substantially less
destructive on Qwen2.5-3B.

FrozenModel mean PPL penalties versus INT8:

- 1.5B L=2: +2.557%
- 3B  L=2: +0.854%

- 1.5B L=4: +3.756%
- 3B  L=4: +0.915%

Thus the severe selective-INT4 degradation observed at 1.5B is not
universal. Model scale materially changes robustness to aggressive
KV-cache quantization in this experiment.

However, this does not validate the learned page selector.

On the five 3B unseen segments:

- Frozen L=2 mean penalty: +0.854%
- Horizon L=2 mean penalty: +0.752%

- Frozen L=4 mean penalty: +0.915%
- Horizon L=4 mean penalty: +0.983%

The learned method is therefore not consistently superior to the
simple remaining-lifetime baseline.

## Oracle audit

The fixed Unseen_3 lifetime-oracle audit again shows that page
sensitivity is highly heterogeneous.

For Qwen2.5-3B:

- Frozen L=2 audit penalty: +0.062%
- Oracle-informed L=2: -0.033%

- Frozen L=4 audit penalty: +0.097%
- Oracle-informed L=4: -0.073%

The small negative oracle values are interpreted as approximately zero
finite-sample effects, not as evidence that INT4 improves the model.

The 3B oracle gap is much smaller than the corresponding 1.5B gap,
which indicates that the larger model is substantially more forgiving
even when page selection is imperfect.

## Predictor interpretation

The basic quantization-distortion feature remains weak.

On the 3B unseen oracle audit:

- frozen predicted total risk vs true total risk:
  rho = 0.322

- V_NRMSE_Max vs normalized intrinsic lifetime risk:
  rho = -0.126

Therefore V_NRMSE_Max should not be presented as a validated intrinsic
page-sensitivity estimator.

## Final project conclusion after cross-model validation

The cross-model experiment changes the interpretation of the original
negative result.

The small 1.5B model was partly responsible for the severe degradation
from selective INT4: Qwen2.5-3B is substantially more tolerant to the
same low-bit policy.

However, the learned online page-risk predictor remains inconsistent
and is not robustly better than a simple horizon-based baseline.

The strongest practical recommendation therefore remains:

**Uniform INT8 KV-cache quantization.**

Across both tested Qwen2.5 model sizes, it approximately halves
analytical KV-cache memory while preserving model quality extremely
well.

Selective INT4 remains promising because:

1. page sensitivity is strongly heterogeneous;
2. the larger model is substantially more robust to selective INT4;
3. oracle-informed page selection achieves approximately zero
   degradation on the 3B audit segment.

Future work should therefore focus on more transferable causal
sensitivity estimators and stronger low-bit quantizers rather than
assuming that recency, attention, confidence, or reconstruction error
alone identifies the safest pages.

## Implementation limitation

All low-bit memory values are analytical packed-cache estimates.

The experimental prototype quantizes and then dequantizes KV values
back into the standard FP16 DynamicCache for model-quality evaluation.
It does not implement a physical packed INT8/INT4 GPU cache or custom
low-bit attention kernels.

Therefore no runtime, bandwidth, physical GPU-memory, or tokens/sec
speedup is claimed.
